/* 2.c */
#include <stdio.h>
#include "a.h"
#include "b.h"

void function_two()
{
  printf("function_2:\n");
}
