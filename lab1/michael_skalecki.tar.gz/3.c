/* 3.c */
#include <stdio.h>
#include "b.h"
#include "c.h"

void function_three()
{
  printf("function_3:\n");
}
